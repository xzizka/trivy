## KBTools
import requests,configparser, pprint, json
from kubernetes import client, config as kube_config
from typing import Final
import urllib3

__all__ = [
    "load_app_config"
    "get_token_from_defectdojo",
    "load_k8s_kb_cluster_info"
]
# Load kubeconfig
try:
  kube_config.load_incluster_config()
except:
  try:
    kube_config.load_kube_config()
  except Exception as e:
    print("Not able to load kubernetes configuration.")
    print("------------")
    print(e)
    print("------------")
  
urllib3.disable_warnings()

is_unmanaged = False # Is the current cluster unmanaged?

def load_app_config():
    global config
    config = configparser.ConfigParser()
    config.read('/tmp/creds/config.ini');
    #username_file = open("/tmp/creds/user","r")
    #password_file = open("/tmp/creds/password","r")
    #username=username_file.read().strip()
    #password=password_file.read().strip()
    with open("/tmp/creds/creds", 'r') as f:
      data=json.load(f)
    f.close()
    config['DefectDojo']['username'] = data['auths']['dockerhub.kb.cz']['username']
    config['DefectDojo']['password'] = data['auths']['dockerhub.kb.cz']['password']
    config['MWS']['api_user'] = data['auths']['dockerhub.kb.cz']['username']
    config['MWS']['api_pass'] = data['auths']['dockerhub.kb.cz']['password']
    #username_file.close()
    #password_file.close()
    return config
    pass

config = load_app_config()

def debug_run():
    global config
    if (str(config['App']['debug']) == "True"):
      return True
    else:
      return False 
    pass

DEBUG_RUN: Final[bool] = debug_run() #Is it a debug run?

def upload_processes_num():
    global config
    if (int(config['App']['processes'])):
      return int(config['App']['processes'])
    else:
      return int(2)
    pass

UPLOAD_PROCS: Final[int] = int(upload_processes_num())

def get_token_from_defectdojo():
    # Receive token from defectdojo
    global config
    dojo_url=config['DefectDojo']['url']+"api/v2/api-token-auth/"
    dojo_user=config['DefectDojo']['username']
    dojo_pass=config['DefectDojo']['password']
    query={'username':dojo_user, 'password': dojo_pass}
    headers={'accept': 'application/json','Content-Type':'application/x-www-form-urlencoded'}
    response = requests.post(dojo_url,data=query,headers=headers,verify=False).json()
    return response['token']
    pass

dojo_api_token = get_token_from_defectdojo()

def load_k8s_kb_cluster_info():
    # Load configmap k8s-kb-cluster-info
    #from kubernetes import client
    resource = client.CoreV1Api()
    cm_name = config['Cluster']['cm_name'].replace('"','')
    cm_namespace = config['Cluster']['cm_namespace'].replace('"','')
    config_cm = resource.read_namespaced_config_map(cm_name,cm_namespace)
    return { 
             "cluster_name": config_cm.data['cluster_name'],
             "tenant_prefix": config_cm.data['tenant_prefix'],
             "env": config_cm.data["cluster_env"].lower()
            }
    pass

cluster_configmap = load_k8s_kb_cluster_info()

def get_nonsystem_namespaces():
    global config
    nonsystem_namespaces = []
    v1 = client.CoreV1Api()
    for namespace in v1.list_namespace().items:
      if namespace.metadata.name[-7:] != '-system' and namespace.metadata.name not in config['Cluster']['excluded_nonsystem_namespaces']:
        nonsystem_namespaces.append(namespace.metadata.name)
    return nonsystem_namespaces         
    pass

nonsystem_namespaces = get_nonsystem_namespaces();

def get_system_namespaces():
    global config
    system_namespaces = []
    v1 = client.CoreV1Api()
    for namespace in v1.list_namespace().items:
      if namespace.metadata.name[-7:] == '-system' or namespace.metadata.name == 'kubernetes-dashboard' or namespace.metadata.name == 'default':
        system_namespaces.append(namespace.metadata.name)
    return system_namespaces         
    pass

system_namespaces = get_system_namespaces();


def get_all_namespaces():
    global config
    all_namespaces = []
    v1 = client.CoreV1Api()
    for namespace in v1.list_namespace().items:
      if namespace.metadata.name not in config['Cluster']['globally_excluded_namespaces']:
        all_namespaces.append(namespace.metadata.name)
    #all_namespaces = ['kube-system'] + all_namespaces
    return all_namespaces         
    pass

all_namespaces = get_all_namespaces();


def init_check():
    passed = False
    if config  and dojo_api_token and cluster_configmap :
      passed = True
    print("Running in DEBUG: ", DEBUG_RUN)
    print("Number of upload processes: ", UPLOAD_PROCS)
    return passed
    pass

def create_infra_producttype():
    global config, dojo_api_token
    dojo_url=config['DefectDojo']['url'] + "api/v2/product_types/"
    headers={'accept': 'application/json', 'Authorization':'Token ' + dojo_api_token}
    params = {'name': config['MWS']['infra_product_type']}
    if (DEBUG_RUN):
      print(params)
    infra_response = requests.get(dojo_url,headers=headers, params=params, verify=False).json()
    if (DEBUG_RUN):
      print(infra_response)
    if infra_response["count"] == 1 :
      return { 'id': infra_response["results"][0]["id"], 'name': infra_response["results"][0]["name"] } 
    else:
      dojo_url=config['DefectDojo']['url']+"api/v2/product_types/"
      query={'name': config['MWS']['infra_product_type'], 'description': 'MWL product_type'}
      headers={'accept': 'application/json', 'Authorization':'Token ' + dojo_api_token}
      create_response = requests.post(dojo_url,data=query,headers=headers,verify=False).json()
      #pprint(type(create_response))
      return { 'id': create_response["id"], 'name': create_response["name"] }
    pass
    
infra_product_type = create_infra_producttype()

def create_speed_producttype():
    global config, dojo_api_token
    dojo_url=config['DefectDojo']['url'] + "api/v2/product_types/"
    headers={'accept': 'application/json', 'Authorization':'Token ' + dojo_api_token}
    params = {'name': config['MWS']['speed_product_type']}
    if (DEBUG_RUN):
      print(params)
    infra_response = requests.get(dojo_url,headers=headers, params=params, verify=False).json()
    if (DEBUG_RUN):
      print(infra_response)
    if infra_response["count"] == 1 :
      return { 'id': infra_response["results"][0]["id"], 'name': infra_response["results"][0]["name"] } 
    else:
      dojo_url=config['DefectDojo']['url']+"api/v2/product_types/"
      query={'name': config['MWS']['speed_product_type'], 'description': 'Speed product_type'}
      headers={'accept': 'application/json', 'Authorization':'Token ' + dojo_api_token}
      create_response = requests.post(dojo_url,data=query,headers=headers,verify=False).json()
      return { 'id': create_response["id"], 'name': create_response["name"] }
    pass

speed_product_type = create_speed_producttype()

def create_unmanaged_producttype():
    global config, dojo_api_token
    dojo_url=config['DefectDojo']['url'] + "api/v2/product_types/"
    headers={'accept': 'application/json', 'Authorization':'Token ' + dojo_api_token}
    params = {'name': 'unmanaged'}
    if (DEBUG_RUN):
      print(params)
    infra_response = requests.get(dojo_url,headers=headers, params=params, verify=False).json()
    if (DEBUG_RUN):
      print(infra_response)
    if infra_response["count"] == 1 :
      return { 'id': infra_response["results"][0]["id"], 'name': infra_response["results"][0]["name"] } 
    else:
      dojo_url=config['DefectDojo']['url']+"api/v2/product_types/"
      query={'name': 'unmanaged', 'description': 'Unamanged product type'}
      headers={'accept': 'application/json', 'Authorization':'Token ' + dojo_api_token}
      create_response = requests.post(dojo_url,data=query,headers=headers,verify=False).json()
      return { 'id': create_response["id"], 'name': create_response["name"] }
    pass

unamanged_product_type = create_unmanaged_producttype()