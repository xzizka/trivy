## test
import KBTools, requests, json, os, shutil
from pprint import pprint
from datetime import datetime
from kubernetes import client
from dateutil.relativedelta import relativedelta
from time import time
from datetime import datetime

class Test:
    def __init__(self, namespace, *args, **kwargs) -> None: #product_id, namespace) -> None:
        self.temp_path = "/tmp/results/"
        self.product_id = kwargs.get('product_id', None)
        self.namespace = namespace
        self.cluster_name = KBTools.cluster_configmap["cluster_name"]
        self.__config = KBTools.config
        self.__api_token = KBTools.dojo_api_token
        os.makedirs(self.temp_path,exist_ok=True)
        self.__eam_application = ""
        self.__eam_application_component = ""
        pass
    
    def load_namespaced_results_from_cluster(self,test_plural):
        self.test_plural = test_plural
        self.test_namespace = self.namespace    
        path_list = []
        custom_object_api = client.CustomObjectsApi()
        list_of_careports = custom_object_api.list_namespaced_custom_object(group="aquasecurity.github.io",version="v1alpha1",plural=self.test_plural,namespace=self.test_namespace)
        for item in list_of_careports["items"]:
          file_path= self.temp_path + item["kind"] + "_" + item["metadata"]["name"] + ".json" #+ item["kind"] + "_"
          out_file = open(file_path, "w")
          del item["metadata"]["managedFields"]
          json.dump(item,out_file,skipkeys= True,ensure_ascii=False)
          out_file.close()
          #print("-----"+ file_path +"-----")
          path_list.append(file_path)
        return path_list
        pass
    
    def load_test_to_variable(self,path):
        with open(path) as f:
          data=json.load(f)
        return data   
    
    def check_engagement_existence(self, engagement_name, product_id) -> bool:
        self.product_id = product_id
        dojo_url=self.__config['DefectDojo']['url'] + "api/v2/engagements/"
        headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
        tags = ['kubernetes', self.cluster_name, self.namespace]
        if KBTools.is_unmanaged:
          tags.append("unamanged")
        params = {'name': engagement_name, 'product': self.product_id, 'tags': tags}
        #print(params)
        respons = requests.get(dojo_url,headers=headers, params=params, verify=False)
        print("Response elapsed - check_engagement_existence: ",respons.elapsed)
        self.response = respons.json()
        if self.response["count"] == 1 :
          return True
        else:
          return False
        pass
        
    def get_engagement_id(self):
        if self.response["results"][0]["id"]:
          return self.response["results"][0]["id"]
        else:
          if self.check_engagement_existence():
            return self.response["results"][0]["id"]
          else:
            return "Current engagement does not exist."    
        pass

    def get_engagement_name(self):
        if self.response["results"][0]["name"]:
          return self.response["results"][0]["name"]
        else:
          if self.check_engagement_existence():
            return self.response["results"][0]["name"]
          else:
            return "Current engagement does not exist."    
        pass
        
    def create_engagement(self, engagement_name, product_id):
        self.product_id = product_id
        dojo_url=self.__config['DefectDojo']['url']+"api/v2/engagements/"
        today=datetime.today()
        next_year=today + relativedelta(years=1)
        tags = ['kubernetes', self.cluster_name, self.namespace]
        if KBTools.is_unmanaged:
          tags.append("unamanged")        
        query={'tags': tags, 'engagement_type': 'CI/CD', 'name': engagement_name, 'product': self.product_id , 'target_start': today.strftime('%Y-%m-%d'),'target_end': next_year.strftime('%Y-%m-%d') }
        headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
        respons = requests.post(dojo_url,data=query,headers=headers,verify=False)
        print("Response elapsed - create_engagement: ",respons.elapsed)
        create_response = respons.json()
        return { 'id': create_response["id"], 'name': create_response["name"] }
        pass

        
    def upload_test_to_dojo(self, product_type_name, endpoint_to_add, engagement_name, namespace, path, product_name):
        dojo_url=KBTools.config['DefectDojo']['url']+"api/v2/reimport-scan/"
        with open(path, 'r') as f:
          data=json.load(f)
        f.close()
        if namespace in KBTools.system_namespaces:
          product_type_name = KBTools.infra_product_type["name"]
        elif namespace.startswith("speed") or namespace.startswith("jx-") or self.namespace in self.__config['Cluster']['speed_namespaces']:
          product_type_name = KBTools.speed_product_type["name"]
        scan_date=data["report"]["updateTimestamp"][:10]
        tags = [ KBTools.cluster_configmap["cluster_name"] , 'kubernetes', namespace, data["kind"] ]
        if KBTools.is_unmanaged:
          tags.append("unamanged")   
        if "artifact" in data['report']:
          image_registry=data['report']['registry']['server'] + "/" + data['report']['artifact']['repository'] + ":" + data['report']['artifact']['tag']
        else:
          image_registry=''
        headers={'accept': 'application/json',
          'Authorization': 'Token '+ KBTools.dojo_api_token}
        query={  
          'product_type_name': product_type_name,
          'active': 'True' ,
          'verified': 'False',
          'close_old_findings': 'True',
          'engagement_name': engagement_name,
          'deduplication_on_engagement': 'True',
          'minimum_severity': 'High',
          'scan_date': scan_date,
          'apply_tags_to_findings': 'True',
          'product_name': product_name,
          'auto_create_context': 'True',
          'scan_type': 'Trivy Operator Scan',
          'test_title': data["kind"] +'_' + data["metadata"]["name"],
          'tags': tags,
          'build_id': image_registry
          }
        if "artifact" in data["report"]:
          query["version"] = data["report"]["artifact"]["tag"]

        files = {
           'file': open(path,'rb')
        }     
        file_size_kb = os.path.getsize(path)/1024
        if endpoint_to_add > 0:
          endpoint_dict = {'endpoint_to_add': endpoint_to_add}
          query.update(endpoint_dict)

        if (KBTools.DEBUG_RUN):
          print("---Upload test to dojo - query---")
          pprint(query)

        print("Engagement name: ",engagement_name," Test upload - START", datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3])
        try:
          response = requests.post(dojo_url,data=query,headers=headers,files=files,verify=False)
        except:
          print("Engagement name: ",engagement_name," Test upload - FAILED END", datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3])
        else:
          print("Engagement name: ",engagement_name," Test upload - END", datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3])
          print("Response elapsed - test_upload: ",response.elapsed, " (",round(file_size_kb,1),"KB)")
        return response.json()
        pass
    
    def load_test():
        shutil.retree(self.temp_path)
        pass

    def report_is_eam(self, comp_namespace, comp_kind, comp_name) -> bool:
        comp_kind = comp_kind.strip()
        if (KBTools.DEBUG_RUN):
          print("---Kind REPORT_IS_EAM - comp_kind---")
          print(comp_kind)
        if comp_kind == 'ReplicaSet':
          appsV1 = client.AppsV1Api() 
          test = appsV1.read_namespaced_replica_set(comp_name,comp_namespace)
          if (KBTools.DEBUG_RUN):
            print("--- REPORT_IS_EAM - name + namespace ---")
            print(test.metadata.name)
            print(test.metadata.namespace)
          if test.metadata.labels is not None:
            if "eamApplication" in test.metadata.labels:
              self.__eam_application = test.metadata.labels["eamApplication"]
              self.__eam_application_component = test.metadata.labels["eamApplicationComponent"]  
              return True
          return False
        elif comp_kind == 'StatefulSet':
          appsV1 = client.AppsV1Api()         
          test = appsV1.read_namespaced_stateful_set(comp_name,comp_namespace)
          if (KBTools.DEBUG_RUN):
            print("--- REPORT_IS_EAM - name + namespace ---")
            print(test.metadata.name)
            print(test.metadata.namespace)
          if test.metadata.labels is not None:
            if "eamApplication" in test.metadata.labels:
              self.__eam_application = test.metadata.labels["eamApplication"]
              self.__eam_application_component = test.metadata.labels["eamApplicationComponent"]            
              return True
          return False
        elif comp_kind == 'NetworkPolicy':
          appsV1 = client.NetworkingV1Api()         
          test = appsV1.read_namespaced_network_policy(comp_name,comp_namespace)
          if (KBTools.DEBUG_RUN):
            print("--- REPORT_IS_EAM - name + namespace ---")
            print(test.metadata.name)
            print(test.metadata.namespace)
          if test.metadata.labels is not None:
            if "eamApplication" in test.metadata.labels:
              self.__eam_application = test.metadata.labels["eamApplication"]
              self.__eam_application_component = test.metadata.labels["eamApplicationComponent"]            
              return True
          return False
        elif comp_kind == 'Job':
          batchV1 = client.BatchV1Api()         
          test = batchV1.read_namespaced_job(comp_name,comp_namespace)
          if (KBTools.DEBUG_RUN):
            print("--- REPORT_IS_EAM - name + namespace ---")
            print(test.metadata.name)
            print(test.metadata.namespace)
          if test.metadata.labels is not None:
            if "eamApplication" in test.metadata.labels:
              self.__eam_application = test.metadata.labels["eamApplication"]
              self.__eam_application_component = test.metadata.labels["eamApplicationComponent"]            
              return True
          return False
        elif comp_kind == 'CronJob':
          batchV1 = client.BatchV1Api()         
          test = batchV1.read_namespaced_cron_job(comp_name,comp_namespace)
          if (KBTools.DEBUG_RUN):
            print("--- REPORT_IS_EAM - name + namespace ---")
            print(test.metadata.name)
            print(test.metadata.namespace)
          if test.metadata.labels is not None:
            if "eamApplication" in test.metadata.labels:
              self.__eam_application = test.metadata.labels["eamApplication"]
              self.__eam_application_component = test.metadata.labels["eamApplicationComponent"]            
              return True
          return False
        elif comp_kind == 'Service':
          coreV1 = client.CoreV1Api()         
          test = coreV1.read_namespaced_service(comp_name,comp_namespace)
          if (KBTools.DEBUG_RUN):
            print("--- REPORT_IS_EAM - name + namespace ---")
            print(test.metadata.name)
            print(test.metadata.namespace)
          if test.metadata.labels is not None:
            if "eamApplication" in test.metadata.labels:
              self.__eam_application = test.metadata.labels["eamApplication"]
              self.__eam_application_component = test.metadata.labels["eamApplicationComponent"]            
              return True
          return False
        elif comp_kind == 'DaemonSet':
          appsV1 = client.AppsV1Api()         
          test = appsV1.read_namespaced_daemon_set(comp_name,comp_namespace)
          if (KBTools.DEBUG_RUN):
            print("--- REPORT_IS_EAM - name + namespace ---")
            print(test.metadata.name)
            print(test.metadata.namespace)
          if test.metadata.labels is not None:
            if "eamApplication" in test.metadata.labels:
              self.__eam_application = test.metadata.labels["eamApplication"]
              self.__eam_application_component = test.metadata.labels["eamApplicationComponent"]            
              return True
          return False
        elif comp_kind == 'Pod':
          coreV1 = client.CoreV1Api()         
          test = coreV1.read_namespaced_pod(comp_name,comp_namespace)
          if (KBTools.DEBUG_RUN):
            print("--- REPORT_IS_EAM - name + namespace ---")
            print(test.metadata.name)
            print(test.metadata.namespace)
          if test.metadata.labels is not None:
            if "eamApplication" in test.metadata.labels:
              self.__eam_application = test.metadata.labels["eamApplication"]
              self.__eam_application_component = test.metadata.labels["eamApplicationComponent"]            
              return True
          return False
        elif comp_kind == 'Ingress':
          V1Ingress = client.NetworkingV1Api()      
          test = V1Ingress.read_namespaced_ingress(comp_name,comp_namespace)
          if (KBTools.DEBUG_RUN):
            print("--- REPORT_IS_EAM - name + namespace ---")
            print(test.metadata.name)
            print(test.metadata.namespace)
          if test.metadata.labels is not None:
            if "eamApplication" in test.metadata.labels:
              self.__eam_application = test.metadata.labels["eamApplication"]
              self.__eam_application_component = test.metadata.labels["eamApplicationComponent"]            
              return True
          return False
        else:
          print('!!!!!!!!!!!!!!!!!!!!!!!!!!!')
          print('Unsupported type:' + comp_kind)
          print('!!!!!!!!!!!!!!!!!!!!!!!!!!!')

        pass

    def get_eam_product(self) -> str:
        # call fucntion report_is_eam() before calling this function to get values for self.__eam_application variable
        return self.__eam_application
        pass

    def get_eam_product_component(self) -> str:
        # call fucntion report_is_eam() before calling this function to get values for self.__eam_application variable
        return self.__eam_application_component
        pass

    def return_endpoint_id_old(self,product_id, engagement_name, resource_kind, resource_name):
        host = ''
        if self.namespace == 'kubernetes-dashboard':
          host = 'dashboard'+'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
        elif self.namespace == 'argocd-system':
          host = 'argocd' +'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
        elif self.namespace == 'dex-system':
          host = 'dex'+'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
        elif self.namespace == 'kube-system':
          host = 'api' +'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
        elif self.namespace == 'oauth2proxy-system':
          host = 'oauth2-proxy' +'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
        
        customApi = client.CustomObjectsApi()
        group = 'networking.istio.io'
        version = 'v1alpha3'
        plural = 'virtualservices'
        endpoints_result = {"items": {}}
        try:
          endpoints_result = customApi.list_namespaced_custom_object(group, version, self.namespace, plural)
        except:
          pass
        #print("---endpoint_results---")
        #pprint(endpoints_result)
        #print(resource_kind)
        for item in endpoints_result["items"]:
          if (KBTools.DEBUG_RUN):
            print("---Endpoint spec - HTTP---")        
            pprint(item["spec"]["http"])
          for http_item in item["spec"]["http"]:
            if "route" in http_item:
            #  print("route: " + str(http_item["route"][0]["destination"]["host"][:-18].split(".")))
            #if list(http_item.keys())[0] == "route":
              svc_identifier=http_item["route"][0]["destination"]["host"][:-18].split(".")
            else:
              continue
          #svc_identifier=item["spec"]["http"][0]["route"][0]["destination"]["host"][:-18].split(".")
          if (KBTools.DEBUG_RUN):
            print("---Endpoint SVC identifier---")          
            print(svc_identifier)
          coreV1 = client.CoreV1Api()
          try:
            test = coreV1.read_namespaced_service(svc_identifier[0],svc_identifier[1])
          except:
            host = ''
            continue
          if (KBTools.DEBUG_RUN):
            pprint("----Endpoint - test.spec.selector----")
            pprint(test.spec.selector)
          if resource_kind == 'Pod': 
            resource_results = coreV1.read_namespaced_pod(name=resource_name,namespace=self.namespace)
          if resource_kind == 'StatefulSet': 
            appv1 = client.AppsV1Api()         
            resource_results = appv1.read_namespaced_stateful_set(name=resource_name,namespace=self.namespace)
          if resource_kind == 'ReplicaSet': 
            appv1 = client.AppsV1Api()   
            resource_results = appv1.read_namespaced_replica_set(name=resource_name,namespace=self.namespace)
          if resource_kind == 'DaemonSet': 
            appv1 = client.AppsV1Api()   
            resource_results = appv1.read_namespaced_daemon_set(name=resource_name,namespace=self.namespace)
          if resource_kind == 'Deployment': 
            appv1 = client.AppsV1Api()             
            resource_results = appv1.read_namespaced_deployment(name=resource_name,namespace=self.namespace)
          if (KBTools.DEBUG_RUN):
            print("---Endpoint resource result---")
            pprint(resource_results)
          for item_resources in resource_results.items:
            if 'app' in test.spec.selector.keys() and 'app' in item_resources.spec.selector.match_labels.keys():
              #print("---APP---")
              #print(test.spec.selector["app"])
              if (KBTools.DEBUG_RUN):
                print("---Endpoint label selectors---")
                pprint(item_resources.spec.selector.match_labels["app"])
              if test.spec.selector["app"] == item_resources.spec.selector.match_labels["app"]:
                host=item["spec"]["hosts"][0]
            #print("------------") 
        if (KBTools.DEBUG_RUN):
          print("---host-endpoint---")
          pprint(host)
#################          
        if host != '' and 1==2:
          dojo_url=self.__config['DefectDojo']['url'] + "api/v2/endpoints/"
          headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
          params = {'host': host } #, 'product': product_id, 'tags': ['kubernetes', self.cluster_name, self.namespace]}
          self.response = requests.get(dojo_url,headers=headers, params=params, verify=False).json()
          if (KBTools.DEBUG_RUN):
            print("---Endpoint response---")
            pprint(self.response)
          if self.response["count"] == 1 :
            return self.response["results"][0]["id"]
        return 0
        pass    
    
    
    def return_endpoint_id(self,product_id, engagement_name, resource_kind, resource_name):
        host = ''
        if self.namespace == 'kubernetes-dashboard':
          host = 'dashboard'+'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
        elif self.namespace == 'argocd-system':
          host = 'argocd' +'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
        elif self.namespace == 'dex-system':
          host = 'dex'+'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
        elif self.namespace == 'kube-system':
          host = 'api' +'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
        elif self.namespace == 'oauth2proxy-system':
          host = 'oauth2-proxy' +'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'

        coreV1 = client.CoreV1Api()

        if resource_kind == 'Pod': 
          resource_results = coreV1.read_namespaced_pod(name=resource_name,namespace=self.namespace)
        if resource_kind == 'StatefulSet': 
          appv1 = client.AppsV1Api()         
          resource_results = appv1.read_namespaced_stateful_set(name=resource_name,namespace=self.namespace)
        if resource_kind == 'ReplicaSet': 
          appv1 = client.AppsV1Api()   
          resource_results = appv1.read_namespaced_replica_set(name=resource_name,namespace=self.namespace)
        if resource_kind == 'DaemonSet': 
          appv1 = client.AppsV1Api()   
          resource_results = appv1.read_namespaced_daemon_set(name=resource_name,namespace=self.namespace)
        if resource_kind == 'Deployment': 
          appv1 = client.AppsV1Api()             
          resource_results = appv1.read_namespaced_deployment(name=resource_name,namespace=self.namespace)
        if (KBTools.DEBUG_RUN):
          print("---Endpoint ID - resource-result---")
          pprint(resource_results)
          print("---Endpoint ID - resource-result - END---")
        
        customApi = client.CustomObjectsApi()
        group = 'networking.istio.io'
        version = 'v1alpha3'
        plural = 'virtualservices'
        endpoints_result = {"items": {}}
        try:
          endpoints_result = customApi.list_namespaced_custom_object(group, version, self.namespace, plural)
        except:
          pass
        #print("---endpoint_results---")
        #pprint(endpoints_result)
        #print(resource_kind)
        for item in endpoints_result["items"]:
          svc_spec_selector = ''
          resource_match_label_app = ''
          if (KBTools.DEBUG_RUN):
            print("---Virtual Service---")
            pprint(item["spec"]["http"])
          for http_item in item["spec"]["http"]:
            if "route" in http_item:
            #  print("route: " + str(http_item["route"][0]["destination"]["host"][:-18].split(".")))
            #if list(http_item.keys())[0] == "route":
              svc_identifier=http_item["route"][0]["destination"]["host"][:-18].split(".")
            else:
              continue
          #svc_identifier=item["spec"]["http"][0]["route"][0]["destination"]["host"][:-18].split(".")
          if (KBTools.DEBUG_RUN):
            print("---SVC-IDENTIFIER---")
            print(svc_identifier)
          try:
            test = coreV1.read_namespaced_service(svc_identifier[0],svc_identifier[1])
          except:
            host = ''
            continue
          if (KBTools.DEBUG_RUN):
            pprint("---- Virtual Service - test.spec.selector----")
            pprint(test.spec.selector)
          if "app" in test.spec.selector:
            svc_spec_selector = test.spec.selector["app"] 

          #print("----SELECTOR---")
          #pprint(resource_results.spec.selector.match_labels) 
          #if 'app' in resource_results.spec.selector.match_labels.keys(): #'app' in resource_results.spec.selector.keys() or
          #  resource_match_label_app = resource_results.spec.selector.match_labels["app"]
          if resource_kind == 'Pod':
            if 'app' in resource_results.metadata.labels.keys(): #resource_results.spec.selector.keys():
              resource_match_label_app = resource_results.metadata.labels["app"] #resource_results.spec.selector["app"]
          else:
            if 'app' in resource_results.spec.selector.match_labels.keys():
              resource_match_label_app = resource_results.spec.selector.match_labels["app"]
          #pprint(resource_results.spec.selector.match_labels["app"])
          if svc_spec_selector == resource_match_label_app:
            host=item["spec"]["hosts"][0]
            if (KBTools.DEBUG_RUN):
              print("---Virtual Service: VYBRANO: True ---")
            break 
        if (KBTools.DEBUG_RUN):
          print("---Virtual Service: host-endpoint---")
          pprint(host)
        if host != '':
          dojo_url=self.__config['DefectDojo']['url'] + "api/v2/endpoints/"
          headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
          params = {'host': host , 'product': product_id } #, 'tags': ['kubernetes', self.cluster_name, self.namespace]}
          if (KBTools.DEBUG_RUN):
            print("---Return endpoint id - params---")
            pprint(params)
          respons = requests.get(dojo_url,headers=headers, params=params, verify=False)
          print("Response elapsed - return_endpoint_id: ",respons.elapsed)
          self.response = respons.json()
          if (KBTools.DEBUG_RUN):
            print("---Return endpoint id - response---")
            pprint(self.response)
          if self.response["count"] == 1 :
            return self.response["results"][0]["id"]
        return 0
        pass    
