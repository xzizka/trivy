#product
import requests
from pprint import pprint
import KBTools, KBTools.product_type

class Product:
    """This class describes a product """
    
    def __init__(self, product_type, namespace, product, *args, **kwargs) -> None:
        self.cluster_name = KBTools.cluster_configmap["cluster_name"]
        self.description = KBTools.cluster_configmap["tenant_prefix"] + " namespace"
        self.namespace = namespace
        self.product_type = product_type
        self.infra_product_type = KBTools.infra_product_type["id"]
        self.speed_product_type = KBTools.speed_product_type["id"]
        self.__api_token = KBTools.dojo_api_token
        self.__config = KBTools.config
        #if namespace == 'kubernetes-dashboard':
        #  self.namespace_truncated = 'dashboard'
        #elif namespace[-7:] == '-system':
        #  self.namespace_truncated = namespace[:-7]
        #elif namespace not in KBTools.config['Cluster']['excluded_nonsystem_namespaces']:
        #  self.namespace_truncated = namespace
        self.product = product #kwargs.get('eamproduct', None) 
        pass

    def check_product_existence(self) -> bool:
        dojo_url=self.__config['DefectDojo']['url'] + "api/v2/products/"
        headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
        if (KBTools.DEBUG_RUN):
          print("---Check product existence - namespace---")
          print("Namespace: " + self.namespace)
        if self.namespace in KBTools.system_namespaces or self.namespace.startswith("speed") or self.namespace.startswith("jx-") or self.namespace in self.__config['Cluster']['speed_namespaces']:
          params = {'name_exact': self.product } #, 'prod_type': self.product_type} #, 'tags': ['kubernetes', self.cluster_name, self.namespace]}
        else:
          params = {'name_exact': self.product }#, 'prod_type': self.product_type } #, 'tags': ['kubernetes', self.cluster_name, self.namespace]}
        respons = requests.get(dojo_url,headers=headers, params=params, verify=False)
        print("Response elapsed - check_product_existence: ",respons.elapsed)
        self.response=respons.json()
        if (KBTools.DEBUG_RUN):
          print("---Check product existence - response---")
          pprint(self.response)
          pprint(params)
          print("----count---")
          pprint(self.response["count"])
        if self.response["count"] == 1 :
          return True
        else:
          return False
        pass

    def get_id(self):
        if self.response["results"][0]["id"]: 
          return self.response["results"][0]["id"]
        else:
          if self.check_product_existence():
            return self.response["results"][0]["id"]
          else:
            return "Current product does not exist."    
        pass
        
    def get_name(self):
        if self.response["results"][0]["name"]:
          return self.response["results"][0]["name"]
        else:
          if self.check_product_existence():
            return self.response["results"][0]["name"]
          else:
            return "Current product does not exist."    
        pass        
        
    def create(self):
        dojo_url=self.__config['DefectDojo']['url']+"api/v2/products/"
        if self.namespace in KBTools.system_namespaces:
          product_type = self.infra_product_type
        elif self.namespace.startswith("speed") or self.namespace in self.__config['Cluster']['speed_namespaces'] or self.namespace.startswith("jx-"):
          product_type = self.speed_product_type
        else:
          product_type= self.product_type
        query={'name': self.product, 'prod_type': product_type, 'description': self.description }#, 'tags': ['kubernetes', self.cluster_name, self.namespace] }
        headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
        #pprint(headers)
        if (KBTools.DEBUG_RUN):
          print("---Create product - query---")
          pprint(query)
        respons = requests.post(dojo_url,data=query,headers=headers,verify=False)
        print("Response elapsed - create_product: ",respons.elapsed)
        create_response= respons.json()
        if (KBTools.DEBUG_RUN):
          print("---Create product - response---")
          pprint(create_response)
        return { 'id': create_response["id"], 'name': create_response["name"] }
        pass
        