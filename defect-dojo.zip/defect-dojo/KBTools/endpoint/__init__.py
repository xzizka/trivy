# endpoint
import requests
from kubernetes import client
import KBTools
from pprint import pprint

class Endpoint:
    """This class describes an endpoint (product_type -> tribe_id+squad_name (tenant prefix) e.g. iao_sq013)"""
    
    def __init__(self, product_id, namespace, *args, **kwargs) -> None:
        self.namespace = namespace
        self.product = product_id
        self.cluster_name = KBTools.cluster_configmap["cluster_name"]
        self.name = KBTools.cluster_configmap["tenant_prefix"]
        self.port = ''
        self.protocol = ''
        self.point=''
        self.__api_token = KBTools.dojo_api_token
        self.__config = KBTools.config
        self.__endpoint_init = kwargs.get('endpoint', None)
        self.__port_init = kwargs.get('port', None)
        self.__protocol_init = kwargs.get('protocol', None)
        self.__labels = kwargs.get('labels', None)
        if self.namespace == 'kubernetes-dashboard':
          self.point = 'dashboard'+'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
          self.protocol = 'https'
          self.port = 443
        elif self.namespace == 'argocd-system':
          self.point = 'argocd' +'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
          self.protocol = 'https'
          self.port = 30555
        elif self.namespace == 'dex-system':
          self.point = 'dex'+'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
          self.protocol = 'https'
          self.port = 32443          
        elif self.namespace == 'kube-system':
          self.point = 'api' +'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
          self.protocol = 'https'
          self.port = 6443          
        elif self.namespace == 'oauth2proxy-system':
          self.point = 'oauth2-proxy' +'.'+ KBTools.cluster_configmap["cluster_name"] +'.service.ist.consul-'+KBTools.cluster_configmap["env"]+'.kb.cz'
          self.protocol = 'https'
          self.port = 31443     
        else:
          if self.__labels:
            self.load_endpoints_eam()     
        
        if self.__endpoint_init:
          self.point = self.__endpoint_init
          self.protocol = self.__protocol_init
          self.port = self.__port_init
        
        
        pass

    def load_endpoint_eam(self, product_name, product_component):
        my_labels = 'eamApplicationComponent={},eamApplication={}'.format(product_component,product_name)
        customApi = client.CustomObjectsApi()
        group = 'networking.istio.io'
        version = 'v1alpha3'
        plural = 'virtualservices'
        endpoints_result = {"items": {}}
        try:
          endpoints_result = customApi.list_namespaced_custom_object(group, version, self.namespace, plural, label_selector=my_labels)
        except:
          pass
        if len(endpoints_result["items"]) > 0:
          self.point=endpoints_result["items"][0]["spec"]["hosts"]
          self.port=80
          if "tls" in endpoints_result["items"][0]["spec"]:
            self.protocol='tls'
          elif "tcp" in endpoints_result["items"][0]["spec"]:
            self.protocol='tcp'
          else:
            self.protocol='http'
          #self.point=''
          #for item in endpoints_result["items"]:
          #  endpoint = {"eamApplication": ["metadata"]["labels"]["eamApplication"], "eamApplicationComponent": item["metadata"]["labels"]["eamApplicationComponent"], "hosts": item["spec"]["hosts"]}
          #  endpoints[item["metadata"]["name"]] = endpoint
          #  endpoint = '' 
            #pprint(item["metadata"]["labels"]["eamApplication"])
            #pprint(item["metadata"]["labels"]["eamApplicationComponent"])
            #pprint(item["spec"]["hosts"][0])
            #pprint(item["metadata"]["name"])
        return self.point
        pass

    def load_endpoints_eam(self, product_name, product_component):
        endpoints = []
        my_labels = 'eamApplicationComponent={},eamApplication={}'.format(product_component,product_name)
        customApi = client.CustomObjectsApi()
        group = 'networking.istio.io'
        version = 'v1alpha3'
        plural = 'virtualservices'
        endpoints_result = {"items": {}}
        try:
          endpoints_result = customApi.list_namespaced_custom_object(group, version, self.namespace, plural, label_selector=my_labels)
        except:
          pass
        if len(endpoints_result["items"]) > 0:
          self.point=''
          for item in endpoints_result["items"]:
            endpoint = {"eamApplication": item["metadata"]["labels"]["eamApplication"], "eamApplicationComponent": item["metadata"]["labels"]["eamApplicationComponent"], "hosts": item["spec"]["hosts"]}
            endpoints.append(endpoint)
            endpoint = '' 
            #endpoints[item["metadata"]["name"]] = endpoint
            #pprint(item["metadata"]["labels"]["eamApplication"])
            #pprint(item["metadata"]["labels"]["eamApplicationComponent"])
            #pprint(item["spec"]["hosts"][0])
            #pprint(item["metadata"]["name"])
        return endpoints
        pass


    def load_endpoint_namespace(self):
        customApi = client.CustomObjectsApi()
        group = 'networking.istio.io'
        version = 'v1alpha3'
        plural = 'virtualservices'
        endpoints_result = {"items": {}}
        try:
          endpoints_result = customApi.list_namespaced_custom_object(group, version, self.namespace, plural)
        except:
          pass
        #pprint(endpoints_result["items"])
        if len(endpoints_result["items"]) > 0:
          self.point=endpoints_result["items"][0]["spec"]["hosts"]
          self.port=80
          if "tls" in endpoints_result["items"][0]["spec"]:
            self.protocol='tls'
          elif "tcp" in endpoints_result["items"][0]["spec"]:
            self.protocol='tcp'
          else:
            self.protocol='http'
          #self.point=''
          #for item in endpoints_result["items"]:
          #  endpoint = {"eamApplication": ["metadata"]["labels"]["eamApplication"], "eamApplicationComponent": item["metadata"]["labels"]["eamApplicationComponent"], "hosts": item["spec"]["hosts"]}
          #  endpoints[item["metadata"]["name"]] = endpoint
          #  endpoint = '' 
            #pprint(item["metadata"]["labels"]["eamApplication"])
            #pprint(item["metadata"]["labels"]["eamApplicationComponent"])
            #pprint(item["spec"]["hosts"][0])
            #pprint(item["metadata"]["name"])
        return endpoints_result["items"]
        pass

    def check_endpoint_existence(self) -> bool:
        dojo_url=self.__config['DefectDojo']['url'] + "api/v2/endpoints/"
        headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
        params = {'host': self.point, 'port': self.port, 'protocol': self.protocol } #, 'product': self.product}
        respons = requests.get(dojo_url,headers=headers, params=params, verify=False)
        print("Response elapsed - check_endpoint_existence: ",respons.elapsed)
        self.response = respons.json()
        if self.response["count"] == 1 :
          return True
        else:
          return False
        pass

    def check_endpoint_existence_host(self, host) -> bool:
        dojo_url=self.__config['DefectDojo']['url'] + "api/v2/endpoints/"
        headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
        params = {'host': host, 'port': self.port, 'protocol': self.protocol } #, 'product': self.product}
        respons = requests.get(dojo_url,headers=headers, params=params, verify=False)
        print("Response elapsed - check_endpoint_existence_host: ",respons.elapsed)
        self.response = respons.json()
        if (KBTools.DEBUG_RUN):
          print("---check_endpoint_existence_host---")
          print(self.response)
        if self.response["count"] == 1 :
          return True
        else:
          return False
        pass


    def get_id(self):
        if self.response["results"][0]["id"]:
          return self.response["results"][0]["id"]
        else: 
          if self.check_endpoint_existence():
            return self.response["results"][0]["id"]
          else:
            return "Current endpoint does not exist."    
        pass

    def create(self):
        dojo_url=self.__config['DefectDojo']['url']+"api/v2/endpoints/"
        tags = ['kubernetes', self.cluster_name, self.namespace]
        if KBTools.is_unmanaged:
          tags.append("unamanged")
        query={'tags': tags,
               'protocol': self.protocol, 
               'host': self.point, 
               'port': self.port, 
               'product': self.product }
        if (KBTools.DEBUG_RUN):
          print("--- Create endpoint query---")
          pprint(query)
        headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
        respons = requests.post(dojo_url,data=query,headers=headers,verify=False)
        print("Response elapsed - create_endpoint: ",respons.elapsed)
        create_response = respons.json()
        #pprint(create_response)
        return { 'id': create_response["id"] }
        pass

    def create_parameters(self, host):
        dojo_url=self.__config['DefectDojo']['url']+"api/v2/endpoints/"
        tags = ['kubernetes', self.cluster_name, self.namespace]
        if KBTools.is_unmanaged:
          tags.append("unamanged")        
        query={'tags': tags,
               'protocol': 'http', 
               'host': host, 
               'port': 80, 
               'product': self.product }
        if (KBTools.DEBUG_RUN):
          print("---Create parameters - query---")
          pprint(query)
        headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
        respons = requests.post(dojo_url,data=query,headers=headers,verify=False)
        print("Response elapsed - create_endpoint_parematers: ",respons.elapsed)
        create_response = respons.json()
        if (KBTools.DEBUG_RUN):
          print("---Create parameters - response---")        
          pprint(create_response)
        return { 'id': create_response["id"] }
        pass
        
    def is_eam_endpoint(self, host):
        my_labels = 'eamApplicationComponent={},eamApplication={}'.format(product_component,product_name)
        customApi = client.CustomObjectsApi()
        group = 'networking.istio.io'
        version = 'v1alpha3'
        plural = 'virtualservices'
        endpoints_result = {"items": {}}
        try:
          endpoints_result = customApi.list_namespaced_custom_object(group, version, self.namespace, plural)
        except:
          pass
        if len(endpoints_result["items"]) > 0:    
          return True  
        else:
          return False
        pass