#product_type
import requests
from pprint import pprint
import KBTools

class ProductType:
    """This class describes a product """
    
    def __init__(self,) -> None:
        self.product_type = ""
        self.description = KBTools.cluster_configmap["tenant_prefix"] + " Apeman project and AgileID"
        self.__api_token = KBTools.dojo_api_token
        self.__config = KBTools.config
        if not self.check_infra_producttype_existence():
          product_type_created = self.create_infra_producttype();
          self.infra_product_type_id = product_type_created["id"]
        else:
          self.infra_product_type_id = self.get_infra_id()
        pass

    def check_producttype_existence(self) -> bool:
        self.get_mws_info()
        dojo_url=self.__config['DefectDojo']['url'] + "api/v2/product_types/"
        headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
        params = {'name': self.product_type}
        respons = requests.get(dojo_url,headers=headers, params=params, verify=False)
        print("Response elapsed - check_producttype_existence: ",respons.elapsed)
        self.response = respons.json()
        if self.response["count"] == 1 :
          return True
        else:
          return False
        pass

    def check_infra_producttype_existence(self):
        dojo_url=self.__config['DefectDojo']['url'] + "api/v2/product_types/"
        headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
        params = {'name': self.__config['MWS']['infra_product_type']}
        respons = requests.get(dojo_url,headers=headers, params=params, verify=False)
        print("Response elapsed - check_infra_producttype_existence: ",respons.elapsed)
        self.infra_response = respons.json()
        if self.infra_response["count"] == 1 :
          return True
        else:
          return False
        pass    
        
    def get_infra_id(self):
        if self.infra_response["results"][0]["id"]:
          return self.infra_response["results"][0]["id"]
        else:
          if self.check_infra_producttype_existence():
            return self.infra_response["results"][0]["id"]
          else:
            return "Current product_type does not exist."    
        pass

    def get_id(self):
        if self.response["results"][0]["id"]:
          return self.response["results"][0]["id"]
        else:
          if self.check_producttype_existence():
            return self.response["results"][0]["id"]
          else:
            return "Current product_type does not exist."    
        pass

    def get_name(self):
        if self.response["results"][0]["name"]:
          return self.response["results"][0]["name"]
        else:
          if self.check_producttype_existence():
            return self.response["results"][0]["name"]
          else:
            return "Current product_type does not exist."    
        pass

    def get_mws_info(self):
        global config
        api_user = KBTools.config['MWS']['api_user']
        api_pass = KBTools.config['MWS']['api_pass']
        api_url = KBTools.config['MWS']['api_url']
        params = { 'clusterName': KBTools.cluster_configmap["cluster_name"], 'withoutNamespaces': ''}
        headers = { 'accept': 'application/json' }
        respons = requests.get(api_url, params=params, headers=headers, verify=False, auth=(api_user,api_pass))
        print("Response elapsed - get_mws_info: ",respons.elapsed)
        mws_response=respons.json()
        if mws_response[0]["cluster_squad_apeman_project"] and str(mws_response[0]["cluster_squad_agileid"]):
          self.product_type = mws_response[0]["cluster_squad_apeman_project"] + "-" + str(mws_response[0]["cluster_squad_agileid"])
        else:
          KBTools.is_unmanaged = True
          self.product_type = "unmanaged"
        pass
        
    def create(self):
        dojo_url=self.__config['DefectDojo']['url']+"api/v2/product_types/"
        query={'name': self.product_type, 'description': self.description}
        headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
        respons = requests.post(dojo_url,data=query,headers=headers,verify=False)
        print("Response elapsed - create product_type: ",respons.elapsed)
        create_response=respons.json()
        return { 'id': create_response["id"], 'name': create_response["name"] }
        pass
        
    def create_infra_producttype(self):
        dojo_url=self.__config['DefectDojo']['url']+"api/v2/product_types/"
        query={'name': self.__config['MWS']['infra_product_type'], 'description': self.description}
        headers={'accept': 'application/json', 'Authorization':'Token ' + self.__api_token}
        respons = requests.post(dojo_url,data=query,headers=headers,verify=False)
        print("Response elapsed - create infra product_type: ",respons.elapsed)
        create_response=respons.json()
        return { 'id': create_response["id"], 'name': create_response["name"] }
        pass        