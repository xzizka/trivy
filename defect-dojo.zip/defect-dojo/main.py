#!/usr/bin/python3

from os import path as ospath
import os
from pprint import pprint
# pip3 install kubernetes
import yaml,json, ast
from kubernetes import client, config as kube_config, dynamic
import KBTools
import KBTools.endpoint, KBTools.test, KBTools.product, KBTools.product_type
import time, multiprocessing, random


def main():
    # Load configuration from config file
    # KBTools.config = load_app_config()
    
    # DefectDojo API token
    # KBTools.dojo_api_token = get_token_from_defectdojo()
    
    # Load configuration for communication with cluster
    # kube_config.load_kube_config() is part of the KBTools module
    
    # Get info about the cluster
    # KBTools.cluster_configmap = load_k8s_kb_cluster_info()
       
    # KBTools.cluster_configmap["cluster_name"] = load_k8s_kb_cluster_info()["cluster_name"]
    # KBTools.cluster_configmap["tenant_prefix"] = load_k8s_kb_cluster_info()["tenant_prefix"]
    # KBTools.cluster_configmap["env"] = load_k8s_kb_cluster_info()["env"].lower()
    
    # Create instance of product_type
    #product_type = KBTools.product_type.ProductType(tenant_prefix, tenant_prefix + " cluster", dojo_api_token, config)
    try:
      KBTools.init_check() 
    except Exception as e:
      print("Inicialization failed")
      print("------------")
      print(e)
      print("------------")

    # Part for system namespaces
    product_type = KBTools.product_type.ProductType()
    product_type_id=''
    product_type_name=''
  
    if product_type.check_producttype_existence():
      product_type_id = product_type.get_id()
      product_type_name = product_type.get_name()
    else:
      product_type_created = product_type.create()
      product_type_id = product_type_created["id"]
      product_type_name = product_type_created["name"]

### Multiprocessing - BEGIN
    print("Version 28")
    pool = multiprocessing.Pool(processes=KBTools.UPLOAD_PROCS)
    for namespace in KBTools.all_namespaces:
      pool.apply_async(import_process, args=(namespace, product_type_id, product_type_name))
    pool.close()
    pool.join()
    
    print("Completed")

### Multiprocessing - END
def import_process(namespace, product_type_id, product_type_name):
      print("Namespace: ",namespace)
      print("----------------------")
      process_id = os.getpid()
      print("Process id: ", process_id)
#    for namespace in KBTools.all_namespaces:
#      if namespace != 'speed-apps-dev':
#        continue
      for crd in ast.literal_eval(KBTools.config['CRDs']['crds_to_use']):
        print("TEST crd -> ", crd)
        test_content = ''
        test_resource_kind = ''
        test_resource_name = ''
        is_eam = ''
        tests = ''
        tests = KBTools.test.Test(namespace)
        path_list=tests.load_namespaced_results_from_cluster(crd)
        if len(path_list) > 0:
          for path in path_list:
            if (KBTools.DEBUG_RUN):
              print(path)
            test_content = tests.load_test_to_variable(path)
            test_resource_kind=test_content["metadata"]["ownerReferences"][0]["kind"]
            test_resource_name=test_content["metadata"]["ownerReferences"][0]["name"]
            is_eam=tests.report_is_eam(namespace, test_resource_kind, test_resource_name)
            if is_eam :
              product_name = tests.get_eam_product()
              engagement_name=tests.get_eam_product_component()
            else:
              engagement_name = KBTools.cluster_configmap["cluster_name"] + '_' + ospath.basename(path)[:-5]
              if namespace == 'kubernetes-dashboard':
                product_name = 'dashboard'
              elif namespace[-7:] == '-system':
                product_name = namespace[:-7]
              elif namespace not in KBTools.config['Cluster']['excluded_nonsystem_namespaces']:
                product_name = namespace            
 
            product = KBTools.product.Product(product_type_id,namespace,product_name)
            proruct_name=''
            product_id=''
            if product.check_product_existence():
              product_id = product.get_id()
              product_name = product.get_name()
            else:
              product_created = product.create()
              product_id = product_created["id"]
              product_name= product_created["name"] 

            endpoint = KBTools.endpoint.Endpoint(product_id,namespace)
            endpoint_id = 0
            if (KBTools.DEBUG_RUN):
              print("---IS-EAM---")
              print(is_eam)
            if namespace in ['kube-system', 'kubernetes-dashboard', 'argocd-system', 'dex-system', 'oauth2proxy-system']:
              if not endpoint.check_endpoint_existence():
                endpoint_created = endpoint.create()
            elif is_eam:
              for endpoint_single in endpoint.load_endpoints_eam(product_name,engagement_name):
                host=endpoint_single["hosts"][0]
                if (KBTools.DEBUG_RUN):
                  print("---ENDPOINT-CREATION-EAM---")
                  print(host)
                if not endpoint.check_endpoint_existence_host(host):
                  endpoint_created=endpoint.create_parameters(host)
            else: 
              for endpoint_single in endpoint.load_endpoint_namespace():
                host=endpoint_single["spec"]["hosts"][0]
                if (KBTools.DEBUG_RUN):
                  print("---ENDPOINT-CREATION---")
                  print(host)
                #pprint(endpoint_single["metadata"]["labels"])
                if "eamApplication" in endpoint_single["metadata"]["labels"] and "eamApplicationComponent" in endpoint_single["metadata"]["labels"]:
                  continue
                if not endpoint.check_endpoint_existence_host(host):
                  endpoint_created=endpoint.create_parameters(host)
            if not tests.check_engagement_existence(engagement_name, product_id):
              engagement_return=tests.create_engagement(engagement_name,product_id)

            if (KBTools.DEBUG_RUN):
              print(path)

            if test_resource_kind in ('Pod','StatefulSet','ReplicaSet','Deployment','DaemonSet'):
              endpoint_id=tests.return_endpoint_id(product_id,engagement_name, test_resource_kind, test_resource_name)
            #enagement_id=tests.return_engagement_id()

            tests.upload_test_to_dojo(product_type_name, endpoint_id, engagement_name, namespace, path, product_name)                

            #if (KBTools.DEBUG_RUN):
            print('Engagement exists: ' + str(tests.check_engagement_existence(engagement_name,product_id)))
            print('Endpoint id: ' + str(endpoint_id))
            print('Engagement name: ' + engagement_name)
            print('Product_name: ' + product_name)
            print('Product id: ' + str(product_id))
            print("---------------------")
      pass
       
if __name__ == '__main__':
    main()